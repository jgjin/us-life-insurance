The data is from naic_report.pdf from the "Annuity Considerations" section of the NAIC report (starting page 127), ignoring US territories
