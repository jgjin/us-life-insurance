The data is from naic_report.pdf from the "Life Insurance" section of the NAIC report (starting page 5), ignoring US territories
